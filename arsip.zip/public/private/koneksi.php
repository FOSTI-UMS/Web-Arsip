<?php 
$conn = mysqli_connect("localhost","u5782209_root","r00tind0l0e1337","u5782209_pengarsipan");
 
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
 
?>